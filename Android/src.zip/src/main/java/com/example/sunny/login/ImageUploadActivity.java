package com.example.sunny.login;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Base64InputStream;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ImageUploadActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView ivPicUpload;
    private Button bChoose,bUpload,bC;
    private EditText etC;
    //private TextView tvTime;
    private final int REQUEST_CAMERA=1;
    Bitmap bitmap;
    //private String UploadURL= "http://192.168.43.142/Android/imageUpload.php";
    //private String AURL= "http://192.168.43.142/Android/attendance.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_upload);

        bChoose= (Button)findViewById(R.id.bChoose);
        bUpload= (Button)findViewById(R.id.bUpload);
        bC= (Button)findViewById(R.id.bC);
        ivPicUpload= (ImageView) findViewById(R.id.ivPicUpload);
        etC= (EditText)findViewById(R.id.etC);
        //tvTime= (TextView) findViewById(R.id.tvTime);
        bChoose.setOnClickListener(this);
        bUpload.setOnClickListener(this);
        bC.setOnClickListener(this);

       /* Constants.sid=Constants.psid1;
        Constants.value= QRcode.s1;
        Constants.start= Constants.start1;
        Constants.end= Constants.end1;*/


    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.bChoose:
                selectImage();
                break;

            case R.id.bUpload:
                uploadImage();
                break;
        }
    }

    private void selectImage()
    {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQUEST_CAMERA && resultCode==RESULT_OK && data!= null){
            Bundle bundle = data.getExtras();
            bitmap = (Bitmap) bundle.get("data");
            ivPicUpload.setImageBitmap(bitmap);
            ivPicUpload.setVisibility(View.VISIBLE);


        }
    }




    private void uploadImage()
    {
        StringRequest stringRequest= new StringRequest(Request.Method.POST, Constants.UploadURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject= new JSONObject(response);
                            String Response = jsonObject.getString("response");
                            Toast.makeText(ImageUploadActivity.this,Response,Toast.LENGTH_LONG).show();
                            ivPicUpload.setImageResource(0);
                            ivPicUpload.setVisibility(View.GONE);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params= new HashMap<>();
                params.put("name",Constants.value);
                params.put("image",imageToString(bitmap));

                return params;
            }
        };
        MySingleton.getInstance(ImageUploadActivity.this).addToRequestQue(stringRequest);
    }

    private String imageToString(Bitmap bitmap)
    {
        ByteArrayOutputStream byteArrayOutputStream= new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);
        byte[] imgBytes= byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(imgBytes,Base64.DEFAULT);
    }

}



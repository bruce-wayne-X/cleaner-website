package com.example.sunny.login;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Created by Sunny on 25-Jun-17.
 */

public class Schedule extends Fragment implements View.OnClickListener {

    private TextView tv1,tv2,tv3,tv4,tv5,tv6,tv7,tv8,tv9,tv10,tv11,tv12,tv13,tv14,tv15,tv16,tv17,tv18,tv19,tv20,tv21,tv22,tv23,tv24;
    private ProgressDialog loading;
    private Button bScan;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.schedule, container, false);


        // buttonGet = (Button) findViewById(R.id.buttonGet);
        tv1 = (TextView) rootView.findViewById(R.id.tv1);
        tv2 = (TextView) rootView.findViewById(R.id.tv2);
        tv3 = (TextView) rootView.findViewById(R.id.tv3);
        tv4 = (TextView) rootView.findViewById(R.id.tv4);
        tv5 = (TextView) rootView.findViewById(R.id.tv5);
        tv6 = (TextView) rootView.findViewById(R.id.tv6);
        tv7 = (TextView) rootView.findViewById(R.id.tv7);
        tv8 = (TextView) rootView.findViewById(R.id.tv8);
        tv9 = (TextView) rootView.findViewById(R.id.tv9);
        tv10 = (TextView) rootView.findViewById(R.id.tv10);
        tv11 = (TextView) rootView.findViewById(R.id.tv11);
        tv12 = (TextView) rootView.findViewById(R.id.tv12);
        tv13= (TextView) rootView.findViewById(R.id.tv13);
        tv14= (TextView) rootView.findViewById(R.id.tv14);
        tv15= (TextView) rootView.findViewById(R.id.tv15);
        tv16 = (TextView) rootView.findViewById(R.id.tv16);
        tv17= (TextView) rootView.findViewById(R.id.tv17);
        tv18= (TextView) rootView.findViewById(R.id.tv18);
        tv19= (TextView) rootView.findViewById(R.id.tv19);
        tv20= (TextView) rootView.findViewById(R.id.tv20);
//        tv21= (TextView) rootView.findViewById(R.id.tv21);
//        tv22= (TextView) rootView.findViewById(R.id.tv22);
//        tv23= (TextView) rootView.findViewById(R.id.tv23);
//        tv24= (TextView) rootView.findViewById(R.id.tv824);
        bScan= (Button) rootView.findViewById(R.id.bScan);

        bScan.setOnClickListener(this);

        getData();
        return rootView;
        // buttonGet.setOnClickListener(this);
    }

    private void getData() {
        String id = Integer.toString(SharedPrefManager.getInstance(getActivity()).getUserId());
        if (id.equals("")) {
            Toast.makeText(getActivity(), "Invalid id", Toast.LENGTH_LONG).show();
            return;
        }
        loading = ProgressDialog.show(getActivity(),"Please wait...","Fetching...",false,false);

        String url = Constants.DATA_URL+id;
        StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                loading.dismiss();
                showJSON(response);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(),error.getMessage().toString(),Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }

    private void showJSON(String response){

//////////// TO KNOW THE PRESENT TIME.///////////
       // TimeZone tz = TimeZone.getTimeZone("GMT+05:30");
       Calendar c = Calendar.getInstance();
//
//        int seconds = c.get(Calendar.SECOND);
        int minutes = c.get(Calendar.MINUTE);
 //       int hour = c.get(Calendar.HOUR);

        DateFormat dateFormat = new SimpleDateFormat("hh:mm a");
        Date date = new Date();
        String str = dateFormat.format(date);
//        Toast.makeText(getActivity(),str,Toast.LENGTH_LONG).show();
        int hour=0;
        if(((str.split(" "))[1]).equals("AM"))
        {
            hour = Integer.parseInt((str.split(":"))[0]);
        }
        else {
            if(Integer.parseInt((str.split(":"))[0])==12){
                hour = 12;
            }
            else {hour= 12+ Integer.parseInt((str.split(":"))[0]);}
        }

        //int minutes = Integer.parseInt((((str.split(":"))[1]).split(" "))[0]);
        //Toast.makeText(getActivity(),(str.split(" "))[1] , Toast.LENGTH_LONG).show();
        float time=  hour + (float)minutes/60 ;
        //Toast.makeText(getActivity(), String.valueOf(time), Toast.LENGTH_LONG).show();


        /*int day = c.get(Calendar.DAY_OF_MONTH);
        int month = c.get(Calendar.MONTH);
        int year = c.get(Calendar.YEAR);
        String date = day + "/" + month + "/" + year;*/

// Assuming that you need date and time in a separate
// textview named txt_date and txt_time.

        //txt_date.setText(date);
        //txt_time.setText(time);

        try {
            JSONObject jsonObject = new JSONObject(response);

            for(int i=1;i<Integer.parseInt(jsonObject.getString("length"));i=i+9)
            {
                switch (i)
                {
                    case (1):
                        tv1.setVisibility(View.VISIBLE);
                        tv1.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v1= String.valueOf(tv1.getText());
                        Constants.s1= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start1 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end1 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid1 = jsonObject.getInt(Integer.toString(i + 8));
                        if(Constants.s1==1){
                            tv1.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s1==2){
                            tv1.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s1==0){
                            if(time>= Constants.end1) {
                                tv1.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv1.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }
                        }
                        break;
                    case(10):
                        tv2.setVisibility(View.VISIBLE);
                        tv2.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v2= String.valueOf(tv2.getText());
                        Constants.s2= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start2 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end2 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid2 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s2==1){
                            tv2.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s2==2){
                            tv2.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s2==0){
                            if(time>= Constants.end2) {
                                tv2.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv2.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }
                        }

                        break;
                    case (19):
                        tv3.setVisibility(View.VISIBLE);
                        tv3.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v3= String.valueOf(tv3.getText());
                        Constants.s3= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start3 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end3 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid3 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s3==1){
                            tv3.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s3==2){
                            tv3.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s3==0){
                            if(time>= Constants.end3) {
                                tv3.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv3.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }
                        }
                        break;
                    case (28):
                        tv4.setVisibility(View.VISIBLE);
                        tv4.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v4= String.valueOf(tv4.getText());
                        Constants.s4= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start4 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end4 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid4 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s4==1){
                            tv4.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s4==2){
                            tv4.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s4==0){
                            if(time>= Constants.end4) {
                                tv4.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv4.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (37):
                        tv5.setVisibility(View.VISIBLE);
                        tv5.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v5= String.valueOf(tv5.getText());
                        Constants.s5= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start5 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end5 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid5 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s5==1){
                            tv5.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s5==2){
                            tv5.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s5==0){
                            if(time>= Constants.end5) {
                                tv5.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv5.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (46):
                        tv6.setVisibility(View.VISIBLE);
                        tv6.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v6= String.valueOf(tv6.getText());
                        Constants.s6= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start6 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end6 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid6 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s6==1){
                            tv6.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s6==2){
                            tv6.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s6==0){
                            if(time>= Constants.end6) {
                                tv6.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv6.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (55):
                        tv7.setVisibility(View.VISIBLE);
                        tv7.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v7= String.valueOf(tv7.getText());
                        Constants.s7= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start7 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end7 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid7 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s7==1){
                            tv7.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s7==2){
                            tv7.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s7==0){
                            if(time>= Constants.end7) {
                                tv7.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv7.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (64):
                        tv8.setVisibility(View.VISIBLE);
                        tv8.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v8= String.valueOf(tv8.getText());
                        Constants.s8= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start8 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end8 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid8 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s8==1){
                            tv8.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s8==2){
                            tv8.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s8==0){
                            if(time>= Constants.end8) {
                                tv8.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv8.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (73):
                        tv9.setVisibility(View.VISIBLE);
                        tv9.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v9= String.valueOf(tv9.getText());
                        Constants.s9= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start9 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end9 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid9 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s9==1){
                            tv9.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s9==2){
                            tv9.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s9==0){
                            if(time>= Constants.end9) {
                                tv9.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv9.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (82):
                        tv10.setVisibility(View.VISIBLE);
                        tv10.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v10= String.valueOf(tv10.getText());
                        Constants.s10= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start10 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end10 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid10 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s10==1){
                            tv10.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s10==2){
                            tv10.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s10==0){
                            if(time>= Constants.end10) {
                                tv10.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv10.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (91):
                        tv11.setVisibility(View.VISIBLE);
                        tv11.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v11= String.valueOf(tv11.getText());
                        Constants.s11= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start11 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end11 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid11 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s11==1){
                            tv11.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s11==2){
                            tv11.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s11==0){
                            if(time>= Constants.end11) {
                                tv11.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv11.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (100):
                        tv12.setVisibility(View.VISIBLE);
                        tv12.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v12= String.valueOf(tv12.getText());
                        Constants.s12= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start12 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end12 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid12 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s12==1){
                            tv12.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s12==2){
                            tv12.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s12==0){
                            if(time>= Constants.end12) {
                                tv12.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv12.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (109):
                        tv13.setVisibility(View.VISIBLE);
                        tv13.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v13= String.valueOf(tv13.getText());
                        Constants.s13= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start13 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end13 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid13 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s13==1){
                            tv13.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s13==2){
                            tv13.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s13==0){
                            if(time>= Constants.end13) {
                                tv13.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv13.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (118):
                        tv14.setVisibility(View.VISIBLE);
                        tv14.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v14= String.valueOf(tv14.getText());
                        Constants.s14= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start14 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end14 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid14 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s14==1){
                            tv14.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s14==2){
                            tv14.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s14==0){
                            if(time>= Constants.end14) {
                                tv14.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv14.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (127):
                        tv15.setVisibility(View.VISIBLE);
                        tv15.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v15= String.valueOf(tv15.getText());
                        Constants.s15= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start15 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end15 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid15 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s15==1){
                            tv15.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s15==2){
                            tv15.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s15==0){
                            if(time>= Constants.end15) {
                                tv15.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv15.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (136):
                        tv16.setVisibility(View.VISIBLE);
                        tv16.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v16= String.valueOf(tv16.getText());
                        Constants.s16= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start16 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end16 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid16 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s16==1){
                            tv16.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s16==2){
                            tv16.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s16==0){
                            if(time>= Constants.end16) {
                                tv16.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv16.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (145):
                        tv17.setVisibility(View.VISIBLE);
                        tv17.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v17= String.valueOf(tv17.getText());
                        Constants.s17= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start17 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end17 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid17 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s17==1){
                            tv17.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s17==2){
                            tv17.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s17==0){
                            if(time>= Constants.end17) {
                                tv17.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv17.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (154):
                        tv18.setVisibility(View.VISIBLE);
                        tv18.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v18= String.valueOf(tv18.getText());
                        Constants.s18= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start18 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end18 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid18 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s18==1){
                            tv18.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s18==2){
                            tv18.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s18==0){
                            if(time>= Constants.end18) {
                                tv18.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv18.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (163):
                        tv19.setVisibility(View.VISIBLE);
                        tv19.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v19= String.valueOf(tv19.getText());
                        Constants.s19= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start19 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end19 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid19 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s19==1){
                            tv19.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s19==2){
                            tv19.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s19==0){
                            if(time>= Constants.end19) {
                                tv19.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv19.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    case (172):
                        tv20.setVisibility(View.VISIBLE);
                        tv20.setText("Time: " + jsonObject.getString(Integer.toString(i)) + " to "
                                + jsonObject.getString(Integer.toString(i + 1)) + "\n"
                                + "Bathroom: " + jsonObject.getString(Integer.toString(i + 2)) + "\n"
                                + "Building: " + jsonObject.getString(Integer.toString(i + 3)) + "   "
                                + "Floor: " + jsonObject.getString(Integer.toString(i + 4)));
                        Constants.v20= String.valueOf(tv20.getText());
                        Constants.s20= jsonObject.getInt(Integer.toString(i + 5)) ;
                        Constants.start20 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 6)));
                        Constants.end20 = Float.parseFloat(jsonObject.getString(Integer.toString(i + 7)));
                        Constants.psid20 = jsonObject.getInt(Integer.toString(i + 8));

                        if(Constants.s20==1){
                            tv20.setBackgroundColor(Color.parseColor("#00E676"));
                        }
                        else if(Constants.s20==2){
                            tv20.setBackgroundColor(Color.parseColor("#FF9100"));
                        }
                        else if(Constants.s20==0){
                            if(time>= Constants.end20) {
                                tv20.setBackgroundColor(Color.parseColor("#D50000"));
                            }
                            else{
                                tv20.setBackgroundColor(Color.parseColor("#FFFFFF"));
                            }                        }
                        break;
                    default:

                }
            }
            //JSONArray result = jsonObject.getJSONArray(Constants.JSON_ARRAY);
            //JSONObject collegeData = result.getJSONObject(0);
            //username = collegeData.getString(Constants.KEY_USERNAME);
            //password = collegeData.getString(Constants.KEY_PASSWORD);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View v) {

        if(v==bScan){
            Intent intent = new Intent(getActivity(),QRcode.class);
            startActivity(intent);
        }
    }



}
package com.example.sunny.login;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sunny on 25-Jun-17.
 */

public class Report extends Fragment {

    /*float[] rainfall={10.8f,58.2f,20.7f,46.6f,51.2f,76.6f,82.8f,43.4f,55.5f,42.2f,123.3f,142.8f};
    String [] months ={"Jan","Feb","Mar","Apr","May","Jun","July","Aug","Sep","Oct","Nov","Dec"};*/
    PieChart chart;
    private ProgressDialog loading;
    public int red=0,green=0,orange=0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.report, container, false);
        chart = (PieChart) rootView.findViewById(R.id.chart);

        getReport();

        return rootView;
    }

    private void setupPieChart() {
        List<PieEntry> pieEntries = new ArrayList<>();
        //for (int i = 0; i < rainfall.length; i++) {
        pieEntries.add(new PieEntry(green, "No. of toilets cleaned on Time"));
        pieEntries.add(new PieEntry(red, "No. of toilets not cleaned"));
        pieEntries.add(new PieEntry(orange, "No. of toilets cleaned late"));
        //}

        PieDataSet dataSet = new PieDataSet(pieEntries, "Report");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        PieData data = new PieData(dataSet);

        chart.setData(data);
        chart.animateY(1000);
        chart.invalidate();
    }

    private void getReport() {

        String id = Integer.toString(SharedPrefManager.getInstance(getActivity()).getUserId());

        if (id.equals("")) {
            Toast.makeText(getActivity(), "Invalid id", Toast.LENGTH_LONG).show();
            return;
        }
        loading = ProgressDialog.show(getActivity(), "Please wait...", "Fetching...", false, false);

        String url = Constants.REPORT_URL + id;
        StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                loading.dismiss();
                showJSON(response);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), error.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);

    }

    private void showJSON(String response) {

        try {

            JSONObject jsonObject = new JSONObject(response);
            red= Integer.parseInt(jsonObject.getString("red"));
            green= Integer.parseInt(jsonObject.getString("green"));
            orange= Integer.parseInt(jsonObject.getString("orange"));

            //Toast.makeText(getActivity(), String.valueOf(orange), Toast.LENGTH_SHORT).show();
            setupPieChart();

        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

}


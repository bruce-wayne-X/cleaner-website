package com.example.sunny.login;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class QRcode extends AppCompatActivity implements View.OnClickListener {

    SurfaceView cameraPreview;
    TextView txtResult;
    BarcodeDetector barcodeDetector;
    CameraSource cameraSource;
    final int RequestCameraPermissionID = 1001;
    public static String s1="",s2="",s3="",s4="",s5="",s6="",s7="",s8="",s9="",s10="",s11="",s12="",s13="",s14="",s15="",s16="",s17="",s18="",s19="",s20="";
    public float time=0;

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case RequestCameraPermissionID: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {

                        return;
                    }
                    try {
                        cameraSource.start(cameraPreview.getHolder());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
            break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qr__user);
        Calendar c = Calendar.getInstance();

        int seconds = c.get(Calendar.SECOND);
        int minutes = c.get(Calendar.MINUTE);
        //int hour = c.get(Calendar.HOUR_OF_DAY);
        //String time = hour + ":" + minutes + ":" + seconds;
        DateFormat dateFormat = new SimpleDateFormat("hh:mm a");
        Date date = new Date();
        String str = dateFormat.format(date);
        int hour=0;
        if(((str.split(" "))[1]).equals("AM"))
        {
            hour = Integer.parseInt((str.split(":"))[0]);
        }
        else {
            if(Integer.parseInt((str.split(":"))[0])==12){
                hour = 12;
            }
            else {hour= 12+ Integer.parseInt((str.split(":"))[0]);}
        }

        time=  hour + (float)minutes/60 ;
        //Toast.makeText(QRcode.this, String.valueOf(time), Toast.LENGTH_LONG).show();



        cameraPreview = (SurfaceView) findViewById(R.id.cameraPreview);
        txtResult = (TextView) findViewById(R.id.txtResult);

        barcodeDetector = new BarcodeDetector.Builder(this)
                .setBarcodeFormats(Barcode.QR_CODE)
                .build();

        cameraSource = new CameraSource.Builder(this, barcodeDetector)
                .setRequestedPreviewSize(640,480)
                .build();


        //Add Event

        cameraPreview.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    //Request Permission
                    ActivityCompat.requestPermissions(QRcode.this,
                            new String[]{Manifest.permission.CAMERA},RequestCameraPermissionID);
                    return;
                }
                try {
                    cameraSource.start(cameraPreview.getHolder());
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                cameraSource.stop();

            }
        });

        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {

            }

            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {


                final SparseArray<Barcode> qrcodes= detections.getDetectedItems();
                if(qrcodes.size() != 0)
                {
                    txtResult.post(new Runnable() {
                        @Override
                        public void run() {
                            //Create Vibrator
                            Vibrator vibrator= (Vibrator)getApplicationContext().getSystemService(Context.VIBRATOR_SERVICE);
                            vibrator.vibrate(1000);
                            txtResult.setText(qrcodes.valueAt(0).displayValue);

                            compareQR();

                        }
                    });

                }

            }
        });

    }

    private void compareQR(){

        if(!Constants.v1.equals("")){String lines1[]= Constants.v1.split("\\n");
        s1= lines1[1]+"\n"+ lines1[2];}

        if(!Constants.v2.equals("")){String lines2[]= Constants.v2.split("\\n");
        s2= lines2[1]+"\n"+ lines2[2];}

        if(!Constants.v3.equals("")){String lines3[]= Constants.v3.split("\\n");
        s3= lines3[1]+"\n"+ lines3[2];}

        if(!Constants.v4.equals("")){String lines4[]= Constants.v4.split("\\n");
        s4= lines4[1]+"\n"+ lines4[2];}

        if(!Constants.v5.equals("")){String lines5[]= Constants.v5.split("\\n");
        s5= lines5[1]+"\n"+ lines5[2];}

        if(!Constants.v6.equals("")){String lines6[]= Constants.v6.split("\\n");
        s6= lines6[1]+"\n"+ lines6[2];}

        if(!Constants.v7.equals("")){String lines7[]= Constants.v7.split("\\n");
        s7= lines7[1]+"\n"+ lines7[2];}

        if(!Constants.v8.equals("")){String lines8[]= Constants.v8.split("\\n");
        s8= lines8[1]+"\n"+ lines8[2];}

        if(!Constants.v9.equals("")){String lines9[]= Constants.v9.split("\\n");
        s9= lines9[1]+"\n"+ lines9[2];}

        if(!Constants.v10.equals("")){String lines10[]= Constants.v10.split("\\n");
        s10= lines10[1]+"\n"+ lines10[2];}

        if(!Constants.v11.equals("")){String lines11[]= Constants.v11.split("\\n");
        s11= lines11[1]+"\n"+ lines11[2];}

        if(!Constants.v12.equals("")){String lines12[]= Constants.v12.split("\\n");
        s12= lines12[1]+"\n"+ lines12[2];}

        if(!Constants.v13.equals("")){String lines13[]= Constants.v13.split("\\n");
        s13= lines13[1]+"\n"+ lines13[2];}

        if(!Constants.v14.equals("")){String lines14[]= Constants.v14.split("\\n");
        s14= lines14[1]+"\n"+ lines14[2];}

        if(!Constants.v15.equals("")){String lines15[]= Constants.v15.split("\\n");
        s15= lines15[1]+"\n"+ lines15[2];}

        if(!Constants.v16.equals("")){String lines16[]= Constants.v16.split("\\n");
        s16= lines16[1]+"\n"+ lines16[2];}

        if(!Constants.v17.equals("")){String lines17[]= Constants.v17.split("\\n");
        s17= lines17[1]+"\n"+ lines17[2];}

        if(!Constants.v18.equals("")){String lines18[]= Constants.v18.split("\\n");
        s18= lines18[1]+"\n"+ lines18[2];}

        if(!Constants.v19.equals("")){String lines19[]= Constants.v19.split("\\n");
        s19= lines19[1]+"\n"+ lines19[2];}

        if(!Constants.v20.equals("")){String lines20[]= Constants.v20.split("\\n");
        s20= lines20[1]+"\n"+ lines20[2];}

        if(s1.equals(txtResult.getText()) && time <=(Constants.end1 + 0.5) && time >= Constants.start1) {
            Constants.sid=Constants.psid1;
            Constants.value= Constants.v1;
            Constants.start= Constants.start1;
            Constants.end= Constants.end1;
            Intent i = new Intent(QRcode.this, AttendanceActivity.class);
            startActivity(i);
            //attendance();
        }

        else if(s2.equals(txtResult.getText())&& time <=(Constants.end2 + 0.5) && time >= Constants.start2){
            Constants.sid=Constants.psid2;
            Constants.value= Constants.v2;
            Constants.start= Constants.start2;
            Constants.end= Constants.end2;
            Intent i= new Intent(QRcode.this,AttendanceActivity.class);
            startActivity(i);
            //attendance();
        }

        else if(s3.equals(txtResult.getText())&& time <=(Constants.end3 + 0.5) && time >= Constants.start3) {
            Constants.sid=Constants.psid3;
            Constants.value= Constants.v3;
            Constants.start= Constants.start3;
            Constants.end= Constants.end3;
            Intent i = new Intent(QRcode.this, AttendanceActivity.class);
            startActivity(i);
            //attendance();
        }

        else if(s4.equals(txtResult.getText())&& time <=(Constants.end4 + 0.5) && time >= Constants.start4){
            Constants.sid=Constants.psid4;
            Constants.value= Constants.v4;
            Constants.start= Constants.start4;
            Constants.end= Constants.end4;
            Intent i= new Intent(QRcode.this,AttendanceActivity.class);
            startActivity(i);
            //attendance();
        }

        else if(s5.equals(txtResult.getText())&& time <=(Constants.end5 + 0.5) && time >= Constants.start5) {
            Constants.sid=Constants.psid5;
            Constants.value= Constants.v5;
            Constants.start= Constants.start5;
            Constants.end= Constants.end5;
            Intent i= new Intent(QRcode.this,AttendanceActivity.class);
            startActivity(i);
            //attendance();
        }

        else if(s6.equals(txtResult.getText())&& time <=(Constants.end6 + 0.5) && time >= Constants.start6) {
            Constants.sid=Constants.psid6;
            Constants.value= Constants.v6;
            Constants.start= Constants.start6;
            Constants.end= Constants.end6;
            Intent i= new Intent(QRcode.this,AttendanceActivity.class);
            startActivity(i);
            //attendance();
        }

        else if(s7.equals(txtResult.getText())&& time <=(Constants.end7 + 0.5) && time >= Constants.start7) {
            Constants.sid=Constants.psid7;
            Constants.value= Constants.v7;
            Constants.start= Constants.start7;
            Constants.end= Constants.end7;
            Intent i= new Intent(QRcode.this,AttendanceActivity.class);
            startActivity(i);
            //attendance();
        }

        else if(s8.equals(txtResult.getText())&& time <=(Constants.end8 + 0.5) && time >= Constants.start8) {
            Constants.sid=Constants.psid8;
            Constants.value= Constants.v8;
            Constants.start= Constants.start8;
            Constants.end= Constants.end8;
            Intent i= new Intent(QRcode.this,AttendanceActivity.class);
            startActivity(i);
            //attendance();
        }

        else if(s9.equals(txtResult.getText())&& time <=(Constants.end9 + 0.5) && time >= Constants.start9) {
            Constants.sid=Constants.psid9;
            Constants.value= Constants.v9;
            Constants.start= Constants.start9;
            Constants.end= Constants.end9;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s10.equals(txtResult.getText())&& time <=(Constants.end10 + 0.5) && time >= Constants.start10) {
            Constants.sid=Constants.psid10;
            Constants.value= Constants.v10;
            Constants.start= Constants.start10;
            Constants.end= Constants.end10;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s11.equals(txtResult.getText()) && time <=(Constants.end11 + 0.5) && time >= Constants.start11) {
            Constants.sid=Constants.psid11;
            Constants.value= Constants.v11;
            Constants.start= Constants.start11;
            Constants.end= Constants.end11;
            Intent i = new Intent(QRcode.this, ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s12.equals(txtResult.getText())&& time <=(Constants.end12 + 0.5) && time >= Constants.start12){
            Constants.sid=Constants.psid12;
            Constants.value= Constants.v12;
            Constants.start= Constants.start12;
            Constants.end= Constants.end12;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s13.equals(txtResult.getText())&& time <=(Constants.end13 + 0.5) && time >= Constants.start13) {
            Constants.sid=Constants.psid13;
            Constants.value= Constants.v13;
            Constants.start= Constants.start13;
            Constants.end= Constants.end13;
            Intent i = new Intent(QRcode.this, ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s14.equals(txtResult.getText())&& time <=(Constants.end14 + 0.5) && time >= Constants.start14){
            Constants.sid=Constants.psid14;
            Constants.value= Constants.v14;
            Constants.start= Constants.start14;
            Constants.end= Constants.end14;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s15.equals(txtResult.getText())&& time <=(Constants.end15 + 0.5) && time >= Constants.start15) {
            Constants.sid=Constants.psid15;
            Constants.value= Constants.v15;
            Constants.start= Constants.start15;
            Constants.end= Constants.end15;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s16.equals(txtResult.getText())&& time <=(Constants.end16 + 0.5) && time >= Constants.start16) {
            Constants.sid=Constants.psid16;
            Constants.value= Constants.v16;
            Constants.start= Constants.start16;
            Constants.end= Constants.end16;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s17.equals(txtResult.getText())&& time <=(Constants.end17 + 0.5) && time >= Constants.start17) {
            Constants.sid=Constants.psid17;
            Constants.value= Constants.v17;
            Constants.start= Constants.start17;
            Constants.end= Constants.end17;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s18.equals(txtResult.getText())&& time <=(Constants.end18 + 0.5) && time >= Constants.start18) {
            Constants.sid=Constants.psid18;
            Constants.value= Constants.v18;
            Constants.start= Constants.start18;
            Constants.end= Constants.end18;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s19.equals(txtResult.getText())&& time <=(Constants.end19 + 0.5) && time >= Constants.start19) {
            Constants.sid=Constants.psid19;
            Constants.value= Constants.v19;
            Constants.start= Constants.start19;
            Constants.end= Constants.end19;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }

        else if(s20.equals(txtResult.getText())&& time <=(Constants.end20 + 0.5) && time >= Constants.start20) {
            Constants.sid=Constants.psid20;
            Constants.value= Constants.v20;
            Constants.start= Constants.start20;
            Constants.end= Constants.end20;
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }
        else { Toast.makeText(QRcode.this, "You are in Wrong Bathroom", Toast.LENGTH_SHORT).show();}
    }

    @Override
    public void onClick(View v) {
     /*   if(v==txtResult){
            Intent i= new Intent(QRcode.this,ImageUploadActivity.class);
            startActivity(i);
        }*/
    }
}

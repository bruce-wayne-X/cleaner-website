package com.example.sunny.login;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ChangePassActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText etop,etnp;
    private Button bChange;
    private ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_pass);

        etop = (EditText) findViewById(R.id.etop);
        etnp = (EditText) findViewById(R.id.etnp);
        bChange = (Button) findViewById(R.id.bChange);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");
        bChange.setOnClickListener(this);
    }

    private void change()
    {
        final String oldp = etop.getText().toString().trim();
        final String newp = etnp.getText().toString().trim();
        final String id = Integer.toString(SharedPrefManager.getInstance(ChangePassActivity.this).getUserId());

        progressDialog.show();

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                Constants.PASS_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            if (!obj.getBoolean("error")) {
                                Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_LONG).show();
                                SharedPrefManager.getInstance(ChangePassActivity.this).logout();
                                finish();
                                startActivity(new Intent(ChangePassActivity.this, Login2Activity.class));
                            } else {
                                Toast.makeText(
                                        getApplicationContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();

                        Toast.makeText(
                                getApplicationContext(),
                                error.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("old_password", oldp);
                params.put("new_password", newp);
                params.put("id", id);
                return params;
            }

        };

        RequestHandler.getInstance(this).addToRequestQueue(stringRequest);
    }


    @Override
    public void onClick(View v) {
        if(v==bChange)
        {
            change();
        }
    }
}

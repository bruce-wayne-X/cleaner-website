package com.example.sunny.login;

import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Document;

/**
 * Created by Sunny on 25-Jun-17.
 */

public class Notifications extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.notifications, container, false);

        EditText txt= (EditText)rootView.findViewById(R.id.txt);
        Button bpdf =(Button)rootView.findViewById(R.id.bpdf);

        bpdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createPDF();
            }
        });
        return rootView;
    }

    private void createPDF()
    {
       // Document doc = new  Document();
        String outPath= Environment.getExternalStorageDirectory()+"/my.pdf";


    }


}

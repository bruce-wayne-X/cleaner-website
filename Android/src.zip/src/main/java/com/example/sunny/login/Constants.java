package com.example.sunny.login;

/**
 * Created by Sunny on 22-Jun-17.
 */

public class Constants {

    private static final String ROOT_URL = "http://10.17.51.27/Android/";

    public static final String URL_REGISTER = ROOT_URL+"register.php";
    public static final String URL_LOGIN = ROOT_URL+"checklogin.php";
    public static final String DATA_URL = ROOT_URL+"getData.php?id=";
    public static final String LEAVE_URL = ROOT_URL+"leave.php";
    public static final String PASS_URL = ROOT_URL+"changePass.php";
    public static final String UploadURL= ROOT_URL+ "imageUpload.php";
    public static final String AURL= ROOT_URL+"attendance.php";
    public static final String REPORT_URL= ROOT_URL+"report.php?id=";

    // int variable for checking the status: 0-not attended, 1-cleaned, 2-late, (0)-not cleaned.
    //initially all the values are assigned to 0 in the attendance table.
    //we wont be changing the value 0 for red to -1 it will all be calculated acc to the time.
    //in schedule we check if time when we open our app is before the time of cleaning ends.
    //the color will change from white to red if the worker does not cleans the toilet.
    //Have given the time margin to be half an hour, if he cleans within that then color orange i.e late
    //otherwise red not cleaned for that particular time slot.
    // now psid is not unique


    public static  int sid =0; //to know which bathroom was scanned.
    public static  String value = ""; //to know which bathroom was scanned.
    public static float start= 0;
    public static float end= 0;
    public static  int s = 0;

    public static  int s1 = 0;
    public static  String v1 = "";  //string for qr in bathroom.
    public static float start1= 0;
    public static float end1= 0;
    public static  int psid1 = 0;  //now we send the id bathroom and floor to get the particular row to take the attendance

    public static  int s2 = 0;
    public static  String v2 = "";
    public static float start2= 0;
    public static float end2= 0;
    public static  int psid2 = 0;

    public static  int s3 = 0;
    public static  String v3 = "";
    public static float start3= 0;
    public static float end3= 0;
    public static  int psid3 = 0;

    public static  int s4 = 0;
    public static  String v4 = "";
    public static float start4= 0;
    public static float end4= 0;
    public static  int psid4 = 0;

    public static  int s5 = 0;
    public static  String v5 = "";
    public static float start5= 0;
    public static float end5= 0;
    public static  int psid5 = 0;

    public static  int s6 = 0;
    public static  String v6 = "";
    public static float start6= 0;
    public static float end6= 0;
    public static  int psid6 = 0;

    public static  int s7 = 0;
    public static  String v7 = "";
    public static float start7= 0;
    public static float end7= 0;
    public static  int psid7 = 0;

    public static  int s8 = 0;
    public static  String v8 = "";
    public static float start8= 0;
    public static float end8= 0;
    public static  int psid8 = 0;

    public static  int s9 = 0;
    public static  String v9 = "";  //string for qr in bathroom.
    public static float start9= 0;
    public static float end9= 0;
    public static  int psid9 = 0;  //now we send the id bathroom and floor to get the particular row to take the attendance

    public static  int s10 = 0;
    public static  String v10 = "";
    public static float start10= 0;
    public static float end10= 0;
    public static  int psid10 = 0;

    public static  int s11 = 0;
    public static  String v11 = "";
    public static float start11= 0;
    public static float end11= 0;
    public static  int psid11 = 0;

    public static  int s12 = 0;
    public static  String v12 = "";
    public static float start12= 0;
    public static float end12= 0;
    public static  int psid12 = 0;

    public static  int s13 = 0;
    public static  String v13 = "";
    public static float start13= 0;
    public static float end13= 0;
    public static  int psid13 = 0;

    public static  int s14 = 0;
    public static  String v14 = "";
    public static float start14= 0;
    public static float end14= 0;
    public static  int psid14 = 0;

    public static  int s15 = 0;
    public static  String v15 = "";
    public static float start15= 0;
    public static float end15= 0;
    public static  int psid15 = 0;

    public static  int s16 = 0;
    public static  String v16 = "";
    public static float start16= 0;
    public static float end16= 0;
    public static  int psid16 = 0;

    public static  int s17 = 0;
    public static  String v17 = "";  //string for qr in bathroom.
    public static float start17= 0;
    public static float end17= 0;
    public static  int psid17 = 0;  //now we send the id bathroom and floor to get the particular row to take the attendance

    public static  int s18 = 0;
    public static  String v18 = "";
    public static float start18= 0;
    public static float end18= 0;
    public static  int psid18 = 0;

    public static  int s19 = 0;
    public static  String v19 = "";
    public static float start19= 0;
    public static float end19= 0;
    public static  int psid19 = 0;

    public static  int s20 = 0;
    public static  String v20 = "";
    public static float start20= 0;
    public static float end20= 0;
    public static  int psid20 = 0;

//    public static  int s21 = 0;
//    public static  String v21 = "";
//    public static float start21= 0;
//    public static float end21= 0;
//    public static  int psid21 = 0;
//
//    public static  int s22 = 0;
//    public static  String v22 = "";
//    public static float start22= 0;
//    public static float end22= 0;
//    public static  int psid22 = 0;
//
//    public static  int s23 = 0;
//    public static  String v23 = "";
//    public static float start23= 0;
//    public static float end23= 0;
//    public static  int psid23 = 0;
//
//    public static  int s24 = 0;
//    public static  String v24 = "";
//    public static float start24= 0;
//    public static float end24= 0;
//    public static  int psid24 = 0;
}

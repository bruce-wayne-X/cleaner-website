package com.example.sunny.login;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AttendanceActivity extends AppCompatActivity {

    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");
        attendance();
    }


    private void attendance() {

        Calendar c = Calendar.getInstance();

        int seconds = c.get(Calendar.SECOND);
        int minutes = c.get(Calendar.MINUTE);
        //int hour = c.get(Calendar.HOUR_OF_DAY);
        //String time = hour + ":" + minutes + ":" + seconds;
        DateFormat dateFormat = new SimpleDateFormat("hh:mm a");
        Date date = new Date();
        String str = dateFormat.format(date);
        int hour=0;
        if(((str.split(" "))[1]).equals("AM"))
        {
            hour = Integer.parseInt((str.split(":"))[0]);
        }
        else {
            if(Integer.parseInt((str.split(":"))[0])==12){
                hour = 12;
            }
            else {hour= 12+ Integer.parseInt((str.split(":"))[0]);}
        }
        float time = hour + (float) minutes / 60;
        //Toast.makeText(AttendanceActivity.this, String.valueOf(time), Toast.LENGTH_SHORT).show();
        if (time >= Constants.end) {
            if (time > Constants.end + 0.5) {         // half hour margin given.
                Constants.s = 0;
            } else {
                Constants.s = 2;
            }
        } else {
            Constants.s = 1;
        }
        String lines[] = Constants.value.split("\\n");
        final String bath = (lines[1].split(" "))[1];
        final String building = (lines[2].split(" "))[1];
        final String floor = (lines[2].split(" "))[5];
        //Toast.makeText(AttendanceActivity.this, bath, Toast.LENGTH_SHORT).show();

        progressDialog.show();

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                Constants.AURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();
                        try {
                            JSONObject obj = new JSONObject(response);
                            if (!obj.getBoolean("error")) {
                                Toast.makeText(
                                        getApplicationContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                                Intent intent = new Intent(AttendanceActivity.this, HomeActivity.class);
                                startActivity(intent);
                                //startActivity(new Intent(getApplicationContext(), HomeActivity.class));
                                //finish();
                            } else {
                                Toast.makeText(
                                        getApplicationContext(),
                                        obj.getString("message"),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();

                        Toast.makeText(
                                getApplicationContext(),
                                error.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                //params.put("wid", Integer.toString(SharedPrefManager.getInstance(ImageUploadActivity.this).getUserId()));


                params.put("bath", bath);
                params.put("building", building);
                params.put("floor", floor);
                params.put("start", Float.toString(Constants.start));
                params.put("end", Float.toString(Constants.end));
                params.put("s", Integer.toString(Constants.s));

                return params;
            }

        };

        RequestHandler.getInstance(this).addToRequestQueue(stringRequest);

    }
}